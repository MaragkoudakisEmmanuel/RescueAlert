# RescueClient

Firebase-integrated Android client app for rescue alerts.